## How to build
```bash
# mac
go build main.go
# windows
env GOOS=windows GOARCH=amd64 go build main.go
```