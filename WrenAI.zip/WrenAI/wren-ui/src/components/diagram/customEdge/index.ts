export { default as ModelEdge } from './ModelEdge';
