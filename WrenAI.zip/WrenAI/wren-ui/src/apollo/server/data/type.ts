export enum SampleDatasetName {
  MUSIC = 'MUSIC',
  NBA = 'NBA',
  ECOMMERCE = 'ECOMMERCE',
}
