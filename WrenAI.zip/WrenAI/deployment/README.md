# Various deployemnt starategies of the app

- [x] [Docker](../docker/)
- [x] [Kubernetes: Kustomizations](./kustomizations/)